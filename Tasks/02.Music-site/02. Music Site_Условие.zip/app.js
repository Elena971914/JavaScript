window.addEventListener('load', solve);

function solve() {
    const allSongs = []
    const genre = document.getElementById('genre')
    const name = document.getElementById('name')
    const author = document.getElementById('author')
    const date = document.getElementById('date')

    const allHits = document.getElementsByClassName('all-hits-container')[0]
    const savedHits = document.getElementsByClassName('saved-container')[0]

    const saveBtn = document.createElement('button')
    const likeBtn = document.createElement('button')
    const deleteBtn = document.createElement('button')

    const addBtn = document.getElementById('add-btn')
    addBtn.addEventListener('click', add)

    function add(e) {
        if (e) { e.preventDefault() }

        if (!genre.value.trim() || !name.value.trim() || !author.value.trim() === "" || !date.value.trim() === "") { return }

        allHits.innerHTML += `
        <div class="hits-info">
        <img src="./static/img/img.png">
        <h2>Genre: ${genre.value}</h2>
        <h2>Name: ${name.value}</h2>
        <h2>Author: ${author.value}</h2>
        <h3>Date: ${date.value}</h3>
        </div>`

        saveBtn.classList.add('save-btn')
        saveBtn.textContent = 'Save song'
        likeBtn.classList.add('like-btn')
        likeBtn.textContent = 'Like song'
        deleteBtn.classList.add('delete-btn')
        deleteBtn.textContent = 'Delete'

        saveBtn.addEventListener('click', save)
        likeBtn.addEventListener('click', like)
        deleteBtn.addEventListener('click', deleteSong)

        document.querySelector('.all-hits-container .hits-info').appendChild(saveBtn)
        document.querySelector('.all-hits-container .hits-info').appendChild(likeBtn)
        document.querySelector('.all-hits-container .hits-info').appendChild(deleteBtn)

        genre.value = ''
        name.value = ''
        author.value = ''
        date.value = ''
    }
    function save() {
        const content = this.parentNode
        savedHits.appendChild(content)
        const saveBtn = content.querySelector('.save-btn');
        const likeBtn = content.querySelector('.like-btn');
        saveBtn.remove();
        likeBtn.remove();
    }
    function like() {
        const curLikes = document.querySelector('#total-likes p').textContent.slice(-1)
        document.querySelector('#total-likes p').textContent = `Total likes: ${Number(curLikes) + 1}`
        likeBtn.disabled = true
    }
    function deleteSong() { this.parentNode.remove() }

}
